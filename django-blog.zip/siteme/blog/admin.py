from django.contrib import admin
from .models import Article , Category, IPAddress

# Admin header change
admin.site.site_header = "وبلاگ جنگویی من"
# The developer of this project is https://github.com/DrSudoSaeed

# Register your models here.
### ============== Category ================== ###
def make_saeed(modeladmin, request, queryset):
    updated = queryset.update(status=True)
    if updated == 1:
        message_bit = "نمایش داده شد."
    else:
        message_bit = "نمایش داده شدند."
    modeladmin.message_user(request,f"{updated} دسته بندی {message_bit}")
make_saeed.short_description = "نمایش داده شود"


def make_saeedNo(modeladmin, request, queryset):
    updated = queryset.update(status=False)
    if updated == 1:
        message_bit = "نمایش داده نشد!"
    else:
        message_bit = "نمایش داده نشدند!"
    modeladmin.message_user(request,f"{updated} دسته بندی {message_bit}")

make_saeedNo.short_description = "نمایش داده نشود!"


### ============== Article ================== ###
def make_published(modeladmin, request, queryset):
    updated = queryset.update(status='p')
    if updated == 1:
        message_bit = "منتشر شد."
    else:
        message_bit = "منتشر شدند"
    modeladmin.message_user(request,f"{updated} مقاله {message_bit}")

make_published.short_description = "انتشار مقالات انتخاب شده"

def make_draft(modeladmin, request, queryset):
    updated = queryset.update(status='d')
    if updated == 1:
        message_bit = "پیش نویس شد."
    else:
        message_bit = "پیش نویس شدند"
    modeladmin.message_user(request,f"{updated} مقاله {message_bit}")
make_draft.short_description = "پیش نویس شدن مقالات انتخاب شده"


class CategoryAdmin(admin.ModelAdmin):
    STATUS_CHOICES = [
    ('d', 'Draft'),
    ('p', 'Published'),
    ('w', 'Withdrawn'),
]
    list_display = ('position','title','slug','parent','status')
    list_filter = (['status'])
    search_fields = ('title','slug')
    prepopulated_fields = {'slug':('title',)}
    actions = [make_saeed,make_saeedNo]


admin.site.register(Category, CategoryAdmin)


class ArticleAdmin(admin.ModelAdmin):
    list_display = ('title','thumbnail_tag','slug','author','jpublish','is_special','status','category_to_str')
    list_filter = ('publish','status','author')
    search_fields = ('title','description')
    prepopulated_fields = {'slug':('title',)}
    ordering = ['status','publish']
    actions = [make_published,make_draft]

    

admin.site.register(Article, ArticleAdmin)
admin.site.register(IPAddress)