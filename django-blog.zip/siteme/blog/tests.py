from django.test import TestCase
# The developer of this project is https://github.com/DrSudoSaeed
# Create your tests here.
