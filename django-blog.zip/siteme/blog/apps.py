from django.apps import AppConfig
# The developer of this project is https://github.com/DrSudoSaeed

class BlogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blog'
    verbose_name = "وبلاگ"
