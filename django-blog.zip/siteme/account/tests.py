from django.test import TestCase

# Create your tests here.
# The developer of this project is https://github.com/DrSudoSaeed