from django.apps import AppConfig
# The developer of this project is https://github.com/DrSudoSaeed

class AccountConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'account'
    verbose_name = 'اکانت'
